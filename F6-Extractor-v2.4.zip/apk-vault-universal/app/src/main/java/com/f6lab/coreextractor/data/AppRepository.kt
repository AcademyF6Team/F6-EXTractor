package com.f6lab.coreextractor.data

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import java.io.File

class AppRepository(private val context: Context) {
    data class AppItem(
        val label: String, val packageName: String, val versionName: String, val versionCode: Long,
        val targetSdk: Int, val isSystem: Boolean, val isLaunchable: Boolean, val isWebApp: Boolean,
        val apkFiles: List<File>, val expectedSplitCount: Int, val totalBytes: Long,
        val icon: android.graphics.drawable.Drawable,
        val architectures: List<String>, val riskTags: List<String>, val source: ForensicInspector.Source,
        val oldTargetSdk: Boolean, val certificateSha256: String
    )

    data class ExportSource(
        val label: String, val packageName: String, val versionName: String, val versionCode: Long,
        val targetSdk: Int, val apkFiles: List<File>, val expectedSplitCount: Int, val totalBytes: Long,
        val architectures: List<String>, val riskTags: List<String>, val certificateSha256: String
    )

    @Suppress("DEPRECATION")
    private fun packageQueryFlags(): Int {
        val signingFlag = if (Build.VERSION.SDK_INT >= 28) PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES
        return PackageManager.GET_META_DATA or PackageManager.GET_PERMISSIONS or signingFlag
    }

    @Suppress("DEPRECATION")
    private fun packageInfo(packageName: String): PackageInfo =
        if (Build.VERSION.SDK_INT >= 33) context.packageManager.getPackageInfo(
            packageName, PackageManager.PackageInfoFlags.of(packageQueryFlags().toLong())
        ) else context.packageManager.getPackageInfo(packageName, packageQueryFlags())

    @Suppress("DEPRECATION")
    fun getInstalledApps(): List<AppItem> {
        val pm = context.packageManager
        val flags = packageQueryFlags()
        val packages = if (Build.VERSION.SDK_INT >= 33) {
            pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(flags.toLong()))
        } else pm.getInstalledPackages(flags)
        val launchIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val launcherPackages = runCatching { pm.queryIntentActivities(launchIntent, 0).mapTo(HashSet()) { it.activityInfo.packageName } }.getOrDefault(emptySet())
        return packages.mapNotNull { info ->
            val app = info.applicationInfo ?: return@mapNotNull null
            val apks = apkFiles(app)
            val expectedSplits = expectedSplitCount(info, app)
            val inspection = ForensicInspector.inspect(context, info, apks)
            AppItem(
                label = label(app, info.packageName), packageName = info.packageName,
                versionName = info.versionName ?: "unknown", versionCode = longVersionCode(info),
                targetSdk = app.targetSdkVersion,
                isSystem = app.flags and (ApplicationInfo.FLAG_SYSTEM or ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0,
                isLaunchable = info.packageName in launcherPackages, isWebApp = isWebAppPackage(info.packageName), apkFiles = apks,
                expectedSplitCount = expectedSplits, totalBytes = apks.sumOf(File::length),
                icon = runCatching { app.loadIcon(pm) }.getOrElse { pm.defaultActivityIcon },
                architectures = inspection.architectures, riskTags = inspection.riskTags,
                source = inspection.source, oldTargetSdk = app.targetSdkVersion < 26,
                certificateSha256 = inspection.certificateSha256
            )
        }.sortedBy { it.label.lowercase() }
    }

    /** Resolves only selected package names; no full package rescan occurs in the export service. */
    fun getExportSource(packageName: String): ExportSource? = runCatching {
        val info = packageInfo(packageName)
        val app = info.applicationInfo ?: return null
        val apks = apkFiles(app)
        val inspection = ForensicInspector.inspect(context, info, apks)
        ExportSource(
            label = label(app, packageName), packageName = packageName,
            versionName = info.versionName ?: "unknown", versionCode = longVersionCode(info),
            targetSdk = app.targetSdkVersion, apkFiles = apks,
            expectedSplitCount = expectedSplitCount(info, app), totalBytes = apks.sumOf(File::length),
            architectures = inspection.architectures, riskTags = inspection.riskTags,
            certificateSha256 = inspection.certificateSha256
        )
    }.getOrNull()


    /** Android exposes no universal web-app flag; classify the documented Chromium WebAPK package family. */
    private fun isWebAppPackage(packageName: String): Boolean =
        packageName.startsWith("com.google.android.webapk.", ignoreCase = true) ||
            packageName.startsWith("org.chromium.webapk.", ignoreCase = true)
    private fun expectedSplitCount(info: PackageInfo, app: ApplicationInfo): Int = maxOf(
        info.splitNames?.size ?: 0,
        app.splitPublicSourceDirs?.size ?: 0
    )

    private fun apkFiles(app: ApplicationInfo): List<File> = buildList {
        (app.publicSourceDir ?: app.sourceDir)?.let { add(File(it)) }
        app.splitPublicSourceDirs?.forEach { add(File(it)) }
    }.distinctBy(File::getAbsolutePath).filter { it.isFile && it.canRead() }

    private fun label(app: ApplicationInfo, fallback: String): String =
        runCatching { app.loadLabel(context.packageManager).toString() }.getOrDefault(fallback).ifBlank { fallback }

    @Suppress("DEPRECATION")
    private fun longVersionCode(info: PackageInfo): Long = if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()
}
