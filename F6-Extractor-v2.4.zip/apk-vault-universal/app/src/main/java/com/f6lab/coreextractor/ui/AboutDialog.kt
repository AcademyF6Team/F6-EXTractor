package com.f6lab.coreextractor.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.f6lab.coreextractor.R

@Composable
fun AboutDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.about_title), color = Color(0xFF00FF66), fontFamily = FontFamily.Monospace) },
        text = {
            Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(stringResource(R.string.about_edition), color = Color(0xFF00D4FF), fontWeight = FontWeight.Bold)
                Text(stringResource(R.string.about_credit), color = Color.White)
                Text(stringResource(R.string.about_description), color = Color.LightGray)
                Text(stringResource(R.string.about_features_title), color = Color(0xFF00FF66), fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                Text(stringResource(R.string.about_features), color = Color.LightGray)
                Text(stringResource(R.string.about_privacy), color = Color(0xFF00D4FF))
                Text(stringResource(R.string.about_owner), color = Color.LightGray)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.close), color = Color(0xFF00FF66)) } },
        containerColor = Color(0xFF101510)
    )
}
