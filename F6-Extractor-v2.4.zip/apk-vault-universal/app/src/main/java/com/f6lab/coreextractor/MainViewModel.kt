package com.f6lab.coreextractor

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.content.pm.PackageManager
import java.io.File
import java.security.MessageDigest
import org.json.JSONArray
import org.json.JSONObject
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.f6lab.coreextractor.data.AppRepository
import com.f6lab.coreextractor.data.SAFStorageManager
import com.f6lab.coreextractor.service.ExportForegroundService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(application: Application) : AndroidViewModel(application) {
    enum class Filter { ALL, USER, SYSTEM, HIGH_RISK, SIDELOADED, OLD_TARGET, WEB_SHORTCUTS }

    data class WebShortcut(val title: String, val url: String)
    data class ApkInspection(val label: String, val packageName: String, val version: String, val versionCode: Long, val targetSdk: Int, val certificateSha256: String, val fileSize: Long)

    data class UiState(
        val apps: List<AppRepository.AppItem> = emptyList(),
        val selected: Set<String> = emptySet(),
        val shortcuts: List<WebShortcut> = emptyList(),
        val selectedShortcuts: Set<String> = emptySet(),
        val shortcutDialogVisible: Boolean = false,
        val shortcutMessage: String? = null,
        val storageUri: Uri? = null,
        val storageName: String = "",
        val storageStats: Pair<Long, Long>? = null,
        val loading: Boolean = true,
        val error: String? = null,
        val query: String = "",
        val filter: Filter = Filter.ALL,
        val exporting: Boolean = false,
        val progressVisible: Boolean = false,
        val uiHidden: Boolean = false,
        val showAbout: Boolean = false,
        val current: String = "",
        val done: Int = 0,
        val total: Int = 0,
        val copiedFiles: Int = 0,
        val totalFiles: Int = 0,
        val bytes: Long = 0,
        val bytesTotal: Long = 0,
        val speedBytesPerSecond: Long = 0,
        val results: List<String> = emptyList(),
        val console: List<String> = emptyList(),
        val failedPackages: List<String> = emptyList(),
        val thermalPaused: Boolean = false,
        val batchFinished: Boolean = false,
        val singleWorkerMode: Boolean = false,
        val hideNotificationNames: Boolean = true,
        val largeTextMode: Boolean = false,
        val backupFiles: List<SAFStorageManager.StoredFile> = emptyList(),
        val inspectingApk: Boolean = false,
        val apkInspection: ApkInspection? = null,
        val apkInspectionError: String? = null
    )

    private val repo = AppRepository(application)
    private val saf = SAFStorageManager(application)
    private val preferences = application.getSharedPreferences("f6_export", Application.MODE_PRIVATE)
    private val mutable = MutableStateFlow(
        UiState(
            console = listOf(localizedContext().getString(R.string.log_offline), localizedContext().getString(R.string.log_private)),
            singleWorkerMode = preferences.getBoolean(PREF_SINGLE_WORKER, false),
            hideNotificationNames = preferences.getBoolean(PREF_HIDE_NOTIFICATION_NAMES, true),
            largeTextMode = preferences.getBoolean(PREF_LARGE_TEXT, false),
            filter = runCatching { Filter.valueOf(preferences.getString(PREF_FILTER, Filter.ALL.name) ?: Filter.ALL.name) }.getOrDefault(Filter.ALL)
        )
    )
    val state = mutable.asStateFlow()

    init {
        observeExport()
        loadShortcuts()
        restoreStoragePermission()
        reload()
    }

    private fun observeExport() = viewModelScope.launch {
        ExportRuntime.state.collectLatest { progress ->
            val results = buildList {
                if (progress.summary.isNotBlank()) add(progress.summary)
                addAll(progress.failureSamples)
            }
            mutable.update { old ->
                old.copy(
                    exporting = progress.running,
                    progressVisible = if (progress.running) !progress.hidden else (!progress.hidden && progress.summary.isNotBlank()),
                    uiHidden = progress.hidden,
                    current = progress.current,
                    done = progress.completedApps,
                    total = progress.totalApps,
                    copiedFiles = progress.copiedFiles,
                    totalFiles = progress.totalFiles,
                    bytes = progress.copiedBytes,
                    bytesTotal = progress.totalBytes,
                    speedBytesPerSecond = progress.bytesPerSecond,
                    failedPackages = progress.failedPackages,
                    thermalPaused = progress.thermalPaused,
                    batchFinished = !progress.running && progress.summary.isNotBlank(),
                    results = results
                )
            }
        }
    }

    private fun restoreStoragePermission() {
        val saved = preferences.getString(PREF_TREE_URI, null) ?: return
        val uri = runCatching { Uri.parse(saved) }.getOrNull() ?: return
        if (!saf.hasPersistedReadWritePermission(uri)) {
            preferences.edit().remove(PREF_TREE_URI).apply()
            mutable.update { it.copy(error = localizedContext().getString(R.string.error_storage_permission_lost)) }
            return
        }
        mutable.update { it.copy(storageUri = uri) }
        viewModelScope.launch {
            val metadata = withContext(Dispatchers.IO) {
                val name = saf.displayName(uri)
                val stats = saf.storageStats(uri)
                val writable = saf.canWrite(uri)
                Triple(name, stats, writable)
            }
            mutable.update {
                it.copy(
                    storageName = metadata.first,
                    storageStats = metadata.second,
                    error = if (metadata.third) it.error else localizedContext().getString(R.string.error_storage_permission_lost)
                )
            }
        }
    }

    fun reload() = viewModelScope.launch {
        mutable.update { it.copy(loading = true, error = null) }
        runCatching { withContext(Dispatchers.IO) { repo.getInstalledApps() } }
            .onSuccess { apps ->
                mutable.update { it.copy(apps = apps, loading = false, error = if (apps.isEmpty()) localizedContext().getString(R.string.error_no_apps) else null) }
                log(R.string.log_indexed, apps.size)
            }
            .onFailure { error ->
                mutable.update { it.copy(loading = false, error = error.message ?: localizedContext().getString(R.string.error_scan)) }
                log(R.string.log_scan_failed)
            }
    }

    fun setQuery(value: String) { mutable.update { it.copy(query = value) } }
    fun setFilter(value: Filter) { preferences.edit().putString(PREF_FILTER, value.name).apply(); mutable.update { it.copy(filter = value) } }
    fun setSingleWorkerMode(value: Boolean) { preferences.edit().putBoolean(PREF_SINGLE_WORKER, value).apply(); mutable.update { it.copy(singleWorkerMode = value) } }
    fun setHideNotificationNames(value: Boolean) { preferences.edit().putBoolean(PREF_HIDE_NOTIFICATION_NAMES, value).apply(); mutable.update { it.copy(hideNotificationNames = value) } }
    fun setLargeTextMode(value: Boolean) { preferences.edit().putBoolean(PREF_LARGE_TEXT, value).apply(); mutable.update { it.copy(largeTextMode = value) } }
    fun showShortcutDialog(show: Boolean) { mutable.update { it.copy(shortcutDialogVisible = show, shortcutMessage = null) } }

    fun consumeShareIntent(intent: Intent?) {
        if (intent?.action != Intent.ACTION_SEND || intent.type?.startsWith("text/") != true) return
        val shared = intent.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()
            ?: intent.clipData?.getItemAt(0)?.coerceToText(getApplication<Application>())?.toString()
            ?: return
        val url = Regex("https?://[^\\s<>\"']+", RegexOption.IGNORE_CASE).find(shared)
            ?.value?.trimEnd('.', ',', ';', ')', ']', '}', '،', '؛') ?: return
        val title = sequenceOf(
            intent.getStringExtra(Intent.EXTRA_SUBJECT),
            intent.getCharSequenceExtra(Intent.EXTRA_TITLE)?.toString(),
            shared.substringBefore(url).trim().takeIf { it.isNotBlank() },
            runCatching { Uri.parse(url).host }.getOrNull()
        ).firstOrNull { !it.isNullOrBlank() }.orEmpty()
        addShortcut(title, url)
    }

    fun addShortcut(title: String, rawUrl: String) {
        val url = normalizeWebUrl(rawUrl)
        if (url == null) {
            mutable.update { it.copy(shortcutMessage = localizedContext().getString(R.string.shortcut_invalid_url)) }
            return
        }
        val normalizedTitle = title.trim().ifBlank { runCatching { Uri.parse(url).host }.getOrNull() ?: url }
        mutable.update { old ->
            val existing = old.shortcuts.firstOrNull { it.url.equals(url, ignoreCase = true) }
            if (existing != null) old.copy(filter = Filter.WEB_SHORTCUTS, selectedShortcuts = old.selectedShortcuts + existing.url,
                shortcutMessage = localizedContext().getString(R.string.shortcut_duplicate))
            else {
                val updated = (old.shortcuts + WebShortcut(normalizedTitle.take(120), url)).sortedBy { it.title.lowercase() }
                persistShortcuts(updated)
                old.copy(filter = Filter.WEB_SHORTCUTS, shortcuts = updated, selectedShortcuts = old.selectedShortcuts + url, shortcutDialogVisible = false,
                    shortcutMessage = localizedContext().getString(R.string.shortcut_saved))
            }
        }
    }

    fun toggleShortcut(url: String) {
        mutable.update { old ->
            val selected = old.selectedShortcuts.toMutableSet()
            if (!selected.add(url)) selected.remove(url)
            old.copy(selectedShortcuts = selected)
        }
    }

    fun selectAllShortcuts() {
        mutable.update { old -> old.copy(selectedShortcuts = old.shortcuts.mapTo(linkedSetOf()) { it.url }) }
    }

    fun clearShortcutSelection() { mutable.update { it.copy(selectedShortcuts = emptySet()) } }

    fun deleteSelectedShortcuts() {
        mutable.update { old ->
            val removed = old.selectedShortcuts
            val updated = old.shortcuts.filterNot { it.url in removed }
            persistShortcuts(updated)
            old.copy(shortcuts = updated, selectedShortcuts = emptySet(), shortcutMessage = localizedContext().getString(R.string.shortcut_deleted))
        }
    }

    fun exportSelectedShortcuts() {
        val snapshot = mutable.value
        val destination = snapshot.storageUri
        if (destination == null || !saf.hasPersistedReadWritePermission(destination)) {
            mutable.update { it.copy(shortcutMessage = localizedContext().getString(R.string.error_choose_storage)) }
            return
        }
        val chosen = snapshot.shortcuts.filter { it.url in snapshot.selectedShortcuts }
        if (chosen.isEmpty()) {
            mutable.update { it.copy(shortcutMessage = localizedContext().getString(R.string.shortcuts_select_first)) }
            return
        }
        viewModelScope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    val payload = JSONObject().put("format", "F6-web-shortcuts-v1").put("links", JSONArray().apply {
                        chosen.forEach { put(JSONObject().put("title", it.title).put("url", it.url)) }
                    }).toString(2)
                    saf.createText(destination, "f6_web_shortcuts.json", "application/json", payload)
                }
            }.onSuccess {
                mutable.update { it.copy(shortcutMessage = localizedContext().getString(R.string.shortcuts_exported, chosen.size)) }
            }.onFailure { error ->
                mutable.update { it.copy(shortcutMessage = error.message ?: localizedContext().getString(R.string.shortcuts_export_failed)) }
            }
        }
    }

    private fun normalizeWebUrl(raw: String): String? = runCatching {
        val candidate = raw.trim()
        if (candidate.isBlank() || candidate.any { it.isWhitespace() }) return null
        val withScheme = if (candidate.startsWith("http://", true) || candidate.startsWith("https://", true)) candidate else "https://$candidate"
        val uri = Uri.parse(withScheme)
        if (uri.scheme !in setOf("http", "https") || uri.host.isNullOrBlank()) null else uri.normalizeScheme().toString()
    }.getOrNull()

    private fun loadShortcuts() {
        val saved = preferences.getString(PREF_SHORTCUTS, null) ?: return
        val list = runCatching {
            val array = JSONArray(saved)
            buildList { for (index in 0 until array.length()) {
                val item = array.getJSONObject(index)
                val url = normalizeWebUrl(item.optString("url")) ?: continue
                add(WebShortcut(item.optString("title").ifBlank { Uri.parse(url).host.orEmpty() }, url))
            } }
        }.getOrDefault(emptyList())
        mutable.update { it.copy(shortcuts = list) }
    }

    private fun persistShortcuts(shortcuts: List<WebShortcut>) {
        val payload = JSONArray().apply { shortcuts.forEach { put(JSONObject().put("title", it.title).put("url", it.url)) } }.toString()
        preferences.edit().putString(PREF_SHORTCUTS, payload).apply()
    }
    fun showAbout(show: Boolean) { mutable.update { it.copy(showAbout = show) } }
    fun closeProgress() { mutable.update { it.copy(progressVisible = false) } }
    fun clearApkInspection() { mutable.update { it.copy(apkInspection = null, apkInspectionError = null) } }
    fun selectAllVisible(packages: List<String>) { mutable.update { it.copy(selected = packages.toSet()) } }
    fun selectFailedPackages() { val failed = mutable.value.failedPackages.toSet(); mutable.update { it.copy(selected = failed) } }

    fun refreshBackupFiles() {
        val uri = mutable.value.storageUri ?: return
        viewModelScope.launch {
            val files = withContext(Dispatchers.IO) { runCatching { saf.listStoredFiles(uri) }.getOrDefault(emptyList()) }
            mutable.update { it.copy(backupFiles = files) }
        }
    }

    fun inspectApk(uri: Uri) {
        mutable.update { it.copy(inspectingApk = true, apkInspection = null, apkInspectionError = null) }
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) { inspectApkFile(uri) }
            mutable.update { it.copy(inspectingApk = false, apkInspection = result.first, apkInspectionError = result.second) }
        }
    }

    @Suppress("DEPRECATION")
    private fun inspectApkFile(uri: Uri): Pair<ApkInspection?, String?> {
        val app = getApplication<Application>()
        val temporary = runCatching { File.createTempFile("f6-inspect-", ".apk", app.cacheDir) }.getOrElse {
            return null to localizedContext().getString(R.string.apk_inspect_failed)
        }
        return try {
            val input = app.contentResolver.openInputStream(uri) ?: error(localizedContext().getString(R.string.apk_inspect_failed))
            input.use { source ->
                temporary.outputStream().buffered(256 * 1024).use { output ->
                    val buffer = ByteArray(64 * 1024)
                    var total = 0L
                    while (true) {
                        val count = source.read(buffer)
                        if (count < 0) break
                        total += count
                        check(total <= MAX_INSPECT_APK_BYTES) { localizedContext().getString(R.string.apk_inspect_too_large) }
                        output.write(buffer, 0, count)
                    }
                }
            }
            val flags = PackageManager.GET_META_DATA or if (Build.VERSION.SDK_INT >= 28) PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES
            val info = app.packageManager.getPackageArchiveInfo(temporary.absolutePath, flags)
                ?: error(localizedContext().getString(R.string.apk_inspect_invalid))
            val applicationInfo = info.applicationInfo ?: error(localizedContext().getString(R.string.apk_inspect_invalid))
            applicationInfo.sourceDir = temporary.absolutePath
            applicationInfo.publicSourceDir = temporary.absolutePath
            val signatures = if (Build.VERSION.SDK_INT >= 28) info.signingInfo?.apkContentsSigners else info.signatures
            val fingerprint = signatures?.firstOrNull()?.toByteArray()?.let { bytes ->
                MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
            } ?: localizedContext().getString(R.string.unavailable)
            val versionCode = if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()
            ApkInspection(applicationInfo.loadLabel(app.packageManager).toString(), info.packageName, info.versionName ?: "unknown", versionCode, applicationInfo.targetSdkVersion, fingerprint, temporary.length()) to null
        } catch (error: Exception) {
            null to (error.message ?: localizedContext().getString(R.string.apk_inspect_failed))
        } finally {
            temporary.delete()
        }
    }

    fun toggle(packageName: String) {
        mutable.update { old ->
            val selection = old.selected.toMutableSet()
            if (!selection.add(packageName)) selection.remove(packageName)
            old.copy(selected = selection)
        }
    }

    fun chooseStorage(uri: Uri) {
        viewModelScope.launch {
            val granted = withContext(Dispatchers.IO) { runCatching { saf.takePersistableReadWritePermission(uri) }.getOrDefault(false) }
            if (!granted) {
                mutable.update { it.copy(error = localizedContext().getString(R.string.error_storage_permission_grant), storageUri = null, storageName = "") }
                return@launch
            }
            preferences.edit().putString(PREF_TREE_URI, uri.toString()).apply()
            val (name, stats, writable) = withContext(Dispatchers.IO) {
                Triple(saf.displayName(uri), saf.storageStats(uri), saf.canWrite(uri))
            }
            mutable.update {
                it.copy(
                    storageUri = uri,
                    storageName = name,
                    storageStats = stats,
                    error = if (writable) null else localizedContext().getString(R.string.error_storage_permission_grant)
                )
            }
            if (writable) log(R.string.log_storage_selected, name)
        }
    }

    fun startExport(batchLabel: String = "", singleWorker: Boolean = mutable.value.singleWorkerMode, hideAppNames: Boolean = mutable.value.hideNotificationNames) {
        val snapshot = mutable.value
        val destination = snapshot.storageUri ?: run {
            mutable.update { it.copy(results = listOf(localizedContext().getString(R.string.error_choose_storage)), progressVisible = true) }
            return
        }
        if (!saf.hasPersistedReadWritePermission(destination)) {
            mutable.update { it.copy(error = localizedContext().getString(R.string.error_storage_permission_lost)) }
            return
        }
        if (snapshot.exporting || ExportRuntime.state.value.running) return
        val selected = snapshot.apps.filter { it.packageName in snapshot.selected }
        if (selected.isEmpty()) {
            mutable.update { it.copy(results = listOf(localizedContext().getString(R.string.error_select_app)), progressVisible = true) }
            return
        }
        val estimatedBytes = selected.fold(0L) { total, app -> saturatingAdd(total, app.totalBytes) }
        val estimatedFiles = selected.sumOf { 1L + it.expectedSplitCount }.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        viewModelScope.launch {
            val free = withContext(Dispatchers.IO) { saf.storageStats(destination)?.first }
            if (free != null && estimatedBytes > free) {
                mutable.update { it.copy(results = listOf(localizedContext().getString(R.string.error_space)), progressVisible = true) }
                return@launch
            }
            ExportRuntime.reset()
            val start = Intent(getApplication<Application>(), ExportForegroundService::class.java).apply {
                action = ExportForegroundService.ACTION_START
                data = destination
                putStringArrayListExtra(ExportForegroundService.EXTRA_PACKAGES, ArrayList(selected.map { it.packageName }))
                putExtra(ExportForegroundService.EXTRA_TOTAL_BYTES, estimatedBytes)
                putExtra(ExportForegroundService.EXTRA_TOTAL_FILES, estimatedFiles)
                putExtra(ExportForegroundService.EXTRA_BATCH_LABEL, batchLabel.take(40))
                putExtra(ExportForegroundService.EXTRA_SINGLE_WORKER, singleWorker)
                putExtra(ExportForegroundService.EXTRA_HIDE_APP_NAMES, hideAppNames)
            }
            try {
                ContextCompat.startForegroundService(getApplication(), start)
                mutable.update { it.copy(exporting = true, progressVisible = true, uiHidden = false, results = emptyList()) }
                log(R.string.log_batch_start, selected.size)
            } catch (error: Exception) {
                mutable.update { it.copy(exporting = false, progressVisible = true, error = localizedContext().getString(R.string.export_start_failed, error.message ?: "")) }
            }
        }
    }

    fun hideExportInterface() {
        val progress = ExportRuntime.state.value
        if (!progress.running) return
        mutable.update { it.copy(uiHidden = true, progressVisible = false) }
        sendServiceAction(ExportForegroundService.ACTION_HIDE_UI)
    }

    fun showExportInterface() {
        if (ExportRuntime.state.value.running) sendServiceAction(ExportForegroundService.ACTION_SHOW_UI)
        else ExportRuntime.show()
    }

    fun stopExport() {
        sendServiceAction(ExportForegroundService.ACTION_CANCEL)
        mutable.update { it.copy(current = localizedContext().getString(R.string.stopped)) }
    }

    private fun sendServiceAction(action: String) {
        val intent = Intent(getApplication<Application>(), ExportForegroundService::class.java).setAction(action)
        runCatching { getApplication<Application>().startService(intent) }
    }

    private fun log(resourceId: Int, vararg args: Any) {
        val message = localizedContext().getString(resourceId, *args)
        mutable.update { old -> old.copy(console = (old.console + "F6> $message").takeLast(80)) }
    }

    private fun localizedContext() = LocaleManager.localizedContext(getApplication<Application>())

    private fun saturatingAdd(left: Long, right: Long): Long =
        if (right > 0L && Long.MAX_VALUE - left < right) Long.MAX_VALUE else left + right

    companion object {
        private const val PREF_TREE_URI = "persisted_tree_uri"
        private const val PREF_SHORTCUTS = "saved_web_shortcuts"
        private const val PREF_FILTER = "preferred_app_filter"
        private const val PREF_SINGLE_WORKER = "single_worker_mode"
        private const val PREF_HIDE_NOTIFICATION_NAMES = "hide_notification_app_names"
        private const val PREF_LARGE_TEXT = "large_text_mode"
        private const val MAX_INSPECT_APK_BYTES = 2L * 1024L * 1024L * 1024L
    }
}
