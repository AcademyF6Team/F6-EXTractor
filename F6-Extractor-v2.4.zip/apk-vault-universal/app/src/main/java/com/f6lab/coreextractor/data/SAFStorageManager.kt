package com.f6lab.coreextractor.data

import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.os.storage.StorageManager
import android.provider.DocumentsContract
import androidx.documentfile.provider.DocumentFile
import com.f6lab.coreextractor.LocaleManager
import com.f6lab.coreextractor.R
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.OutputStream
import java.security.MessageDigest
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import java.util.concurrent.ConcurrentHashMap

class SAFStorageManager(private val context: Context) {
    companion object { const val BUFFER_BYTES = 256 * 1024; private const val PROGRESS_INTERVAL_MS = 750L }
    private val treeRoots = ConcurrentHashMap<String, DocumentFile>()
    private val reservedNames = ConcurrentHashMap<String, MutableSet<String>>()
    private val nameCacheLock = Any()

    data class StoredFile(val uri: Uri, val name: String, val mimeType: String?, val size: Long)

    /** Read-only, single-folder inventory. It never deletes, renames, or writes to the selected tree. */
    fun listStoredFiles(uri: Uri): List<StoredFile> = treeRoot(uri).listFiles()
        .filter { it.isFile && (it.name.orEmpty().endsWith(".apk", true) || it.name.orEmpty().endsWith(".apks", true) || it.name.orEmpty().endsWith(".html", true) || it.name.orEmpty().endsWith(".txt", true) || it.name.orEmpty().endsWith(".json", true)) }
        .map { StoredFile(it.uri, it.name.orEmpty(), it.type, it.length().coerceAtLeast(0L)) }
        .sortedBy { it.name.lowercase() }

    data class Exported(
        val displayName: String,
        val packageName: String,
        val version: String,
        val versionCode: Long,
        val size: Long,
        val hashes: List<Pair<String, String>>,
        val isSplit: Boolean,
        val targetSdk: Int,
        val architectures: List<String>,
        val riskTags: List<String>,
        val certificateSha256: String
    )

    private fun treeRoot(uri: Uri): DocumentFile = treeRoots.getOrPut(uri.toString()) {
        DocumentFile.fromTreeUri(context, uri) ?: error(localized(R.string.error_storage_unavailable))
    }

    fun displayName(uri: Uri): String = runCatching { treeRoot(uri).name }
        .getOrNull()?.takeIf { it.isNotBlank() } ?: localized(R.string.storage_external)

    /** Acquires and verifies persistent READ+WRITE SAF grants; never assumes a picker URI is durable. */
    fun takePersistableReadWritePermission(uri: Uri): Boolean {
        val flags = android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        return runCatching {
            val existing = context.contentResolver.persistedUriPermissions.firstOrNull { it.uri == uri }
            if (existing == null || !existing.isReadPermission || !existing.isWritePermission) {
                context.contentResolver.takePersistableUriPermission(uri, flags)
            }
            hasPersistedReadWritePermission(uri)
        }.getOrDefault(false)
    }

    fun hasPersistedReadWritePermission(uri: Uri): Boolean =
        runCatching { context.contentResolver.persistedUriPermissions.any { it.uri == uri && it.isReadPermission && it.isWritePermission } }.getOrDefault(false)

    fun canWrite(uri: Uri): Boolean = runCatching { hasPersistedReadWritePermission(uri) && treeRoot(uri).canWrite() }.getOrDefault(false)

    fun storageStats(uri: Uri): Pair<Long, Long>? {
        if (Build.VERSION.SDK_INT < 30) return null
        val id = runCatching { DocumentsContract.getTreeDocumentId(uri).substringBefore(':') }.getOrNull() ?: return null
        val volume = (context.getSystemService(Context.STORAGE_SERVICE) as StorageManager).storageVolumes.firstOrNull {
            it.uuid?.equals(id, true) == true || id == "primary" && it.isPrimary
        } ?: return null
        val dir = volume.directory ?: return null
        return dir.usableSpace to dir.totalSpace
    }

    /** Must be called from Dispatchers.IO. The callback is throttled and never invoked for each buffer read. */
    fun export(
        uri: Uri,
        app: AppRepository.ExportSource,
        onBytes: (copiedForApp: Long, totalForApp: Long) -> Unit,
        isCancelled: () -> Boolean,
        batchLabel: String = "",
        shouldPause: () -> Boolean = { false },
        onThermalPause: (Boolean) -> Unit = {}
    ): Exported {
        if (isCancelled()) throw java.util.concurrent.CancellationException(localized(R.string.error_export_stopped))
        val root = treeRoot(uri)
        check(root.canWrite()) { localized(R.string.error_storage_write) }
        val sources = app.apkFiles.filter { it.isFile && it.canRead() }
        check(sources.isNotEmpty()) { localized(R.string.error_apk_unreadable) }
        val expectedApkCount = app.expectedSplitCount + 1
        check(sources.size == expectedApkCount) {
            localized(R.string.error_incomplete_splits, expectedApkCount, sources.size)
        }
        val safe = app.label.replace(Regex("[^\\p{L}\\p{N}._ -]"), "_").trim().ifBlank { "App" }
        val multi = app.expectedSplitCount > 0
        val labelPrefix = batchLabel.trim().replace(Regex("[^\\p{L}\\p{N}._ -]"), "_").take(40).trim().let { if (it.isBlank()) "" else "${it}_" }
        val safeVersion = app.versionName.replace(Regex("[^\\p{L}\\p{N}._-]"), "_").ifBlank { "unknown" }
        val safePackage = app.packageName.replace(Regex("[^\\p{L}\\p{N}._-]"), "_")
        val requestedName = "${labelPrefix}${safe}_v${safeVersion}_${safePackage}.${if (multi) "apks" else "apk"}"
        val name = reserveUniqueName(root, requestedName)
        val doc = root.createFile(if (multi) "application/zip" else "application/vnd.android.package-archive", name)
            ?: run { releaseReservedName(root, name); error(localized(R.string.error_file_create)) }
        val actualName = doc.name?.takeIf { it.isNotBlank() } ?: name
        val total = sources.sumOf(File::length)
        val hashes = ArrayList<Pair<String, String>>(sources.size)
        var copied = 0L
        try {
            val raw = context.contentResolver.openOutputStream(doc.uri, "w") ?: error(localized(R.string.error_output_open))
            BufferedOutputStream(raw, BUFFER_BYTES).use { buffered ->
                if (multi) {
                    ZipOutputStream(buffered).use { zip ->
                        // APKs are already compressed; level 0 avoids spending CPU recompressing them.
                        zip.setLevel(Deflater.NO_COMPRESSION)
                        val usedNames = HashSet<String>(sources.size)
                        sources.forEachIndexed { index, file ->
                            if (isCancelled()) throw java.util.concurrent.CancellationException(localized(R.string.error_export_stopped))
                            var entryName = if (index == 0) "base.apk" else file.name.substringAfterLast('/').takeIf { it.endsWith(".apk", true) } ?: "split_${index}.apk"
                            if (!usedNames.add(entryName)) {
                                entryName = "split_${index}_${entryName.substringAfterLast('/')}"
                                check(usedNames.add(entryName)) { localized(R.string.error_file_create) }
                            }
                            zip.putNextEntry(ZipEntry(entryName))
                            val result = copy(file, zip, copied, total, isCancelled, onBytes, shouldPause, onThermalPause)
                            copied = result.first
                            hashes.add(entryName to result.second)
                            zip.closeEntry()
                        }
                    }
                } else {
                    val result = copy(sources.first(), buffered, 0L, total, isCancelled, onBytes, shouldPause, onThermalPause)
                    copied = result.first
                    hashes.add(actualName to result.second)
                    buffered.flush()
                }
            }
            return Exported(
                displayName = actualName, packageName = app.packageName, version = app.versionName,
                versionCode = app.versionCode, size = copied, hashes = hashes, isSplit = multi,
                targetSdk = app.targetSdk, architectures = app.architectures, riskTags = app.riskTags,
                certificateSha256 = app.certificateSha256
            )
        } catch (error: Exception) {
            runCatching { doc.delete() }
            releaseReservedName(root, name)
            throw error
        }
    }


    private fun reserveUniqueName(root: DocumentFile, requested: String): String {
        val key = root.uri.toString()
        val used = reservedNames[key] ?: synchronized(nameCacheLock) {
            reservedNames.getOrPut(key) {
                ConcurrentHashMap.newKeySet<String>().apply { root.listFiles().mapNotNullTo(this) { it.name } }
            }
        }
        if (used.add(requested)) return requested
        val dot = requested.lastIndexOf('.')
        val stem = if (dot > 0) requested.substring(0, dot) else requested
        val suffix = if (dot > 0) requested.substring(dot) else ""
        var index = 2
        while (true) {
            val candidate = "$stem ($index)$suffix"
            if (used.add(candidate)) return candidate
            index++
        }
    }

    private fun releaseReservedName(root: DocumentFile, name: String) {
        reservedNames[root.uri.toString()]?.remove(name)
    }

    private fun copy(
        file: File,
        out: OutputStream,
        start: Long,
        total: Long,
        cancelled: () -> Boolean,
        progress: (Long, Long) -> Unit,
        shouldPause: () -> Boolean,
        onThermalPause: (Boolean) -> Unit
    ): Pair<Long, String> {
        val digest = MessageDigest.getInstance("SHA-256")
        var done = start
        var lastProgressAt = SystemClock.elapsedRealtime()
        val buffer = ByteArray(BUFFER_BYTES)
        BufferedInputStream(file.inputStream(), BUFFER_BYTES).use { input ->
            while (true) {
                if (cancelled() || Thread.currentThread().isInterrupted) throw java.util.concurrent.CancellationException(localized(R.string.error_export_stopped))
                var announcedPause = false
                try {
                    while (shouldPause()) {
                        if (cancelled()) throw java.util.concurrent.CancellationException(localized(R.string.error_export_stopped))
                        if (!announcedPause) { onThermalPause(true); announcedPause = true }
                        try { Thread.sleep(1000L) } catch (interrupted: InterruptedException) {
                            Thread.currentThread().interrupt()
                            throw java.util.concurrent.CancellationException(localized(R.string.error_export_stopped))
                        }
                    }
                } finally {
                    if (announcedPause) onThermalPause(false)
                }
                val n = input.read(buffer)
                if (n < 0) break
                out.write(buffer, 0, n)
                digest.update(buffer, 0, n)
                done += n
                val now = SystemClock.elapsedRealtime()
                if (now - lastProgressAt >= PROGRESS_INTERVAL_MS) {
                    progress(done, total)
                    lastProgressAt = now
                }
            }
        }
        progress(done, total)
        return done to digest.digest().toHexString()
    }

    private fun ByteArray.toHexString(): String {
        val chars = CharArray(size * 2)
        val hex = "0123456789abcdef"
        for (i in indices) {
            val value = this[i].toInt() and 0xff
            chars[i * 2] = hex[value ushr 4]
            chars[i * 2 + 1] = hex[value and 0x0f]
        }
        return String(chars)
    }

    private fun localized(resource: Int, vararg args: Any): String = LocaleManager.localizedContext(context).getString(resource, *args)

    fun createText(uri: Uri, name: String, mime: String, text: String) {
        val root = treeRoot(uri)
        val reserved = reserveUniqueName(root, name)
        val file = try { root.createFile(mime, reserved) ?: error(localized(R.string.error_file_create) + ": $reserved") }
        catch (error: Exception) { releaseReservedName(root, reserved); throw error }
        try {
            context.contentResolver.openOutputStream(file.uri, "w")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(text) }
                ?: error(localized(R.string.error_output_open) + ": $reserved")
        } catch (error: Exception) {
            runCatching { file.delete() }
            releaseReservedName(root, reserved)
            throw error
        }
    }
}
