package com.f6lab.coreextractor.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.graphics.Bitmap
import android.net.Uri
import android.util.LruCache
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.f6lab.coreextractor.LocaleManager
import com.f6lab.coreextractor.MainViewModel
import com.f6lab.coreextractor.R
import com.f6lab.coreextractor.data.AppRepository
import com.f6lab.coreextractor.data.ForensicInspector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.ceil

private val Background = Color(0xFF080D12)
private val SurfaceCard = Color(0xFF111A20)
private val SurfaceRaised = Color(0xFF17232A)
private val Emerald = Color(0xFF00D68F)
private val Cyan = Color(0xFF44D9E6)
private val Amber = Color(0xFFFFC857)
private val ErrorRed = Color(0xFFFF6677)
private val iconCache = LruCache<String, Bitmap>(64)

private enum class AppTab { BACKUP, WEB, TOOLS }

@Composable
fun F6Screen(model: MainViewModel) {
    val state by model.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var activeTab by remember { mutableStateOf(AppTab.BACKUP) }
    var showConsole by remember { mutableStateOf(false) }
    var shortcutTitle by remember { mutableStateOf("") }
    var shortcutUrl by remember { mutableStateOf("") }
    var confirmDeleteShortcuts by remember { mutableStateOf(false) }
    var showBatchPreview by rememberSaveable { mutableStateOf(false) }
    var batchLabel by rememberSaveable { mutableStateOf("") }
    var diagnosticPreview by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? -> uri?.let(model::chooseStorage) }
    val apkPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? -> uri?.let(model::inspectApk) }
    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        model.startExport(batchLabel, state.singleWorkerMode, state.hideNotificationNames)
    }
    val startExport = {
        if (state.storageUri == null || state.selected.isEmpty()) model.startExport()
        else showBatchPreview = true
    }
    val confirmExport = {
        showBatchPreview = false
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else model.startExport(batchLabel, state.singleWorkerMode, state.hideNotificationNames)
    }

    val shown = remember(state.apps, state.query, state.filter) {
        state.apps.filter { app ->
            val match = when (state.filter) {
                MainViewModel.Filter.ALL -> true
                MainViewModel.Filter.USER -> !app.isSystem
                MainViewModel.Filter.SYSTEM -> app.isSystem
                MainViewModel.Filter.HIGH_RISK -> app.riskTags.isNotEmpty()
                MainViewModel.Filter.SIDELOADED -> app.source != ForensicInspector.Source.GOOGLE_PLAY
                MainViewModel.Filter.OLD_TARGET -> app.oldTargetSdk
                MainViewModel.Filter.WEB_SHORTCUTS -> app.isWebApp
            }
            match && (state.query.isBlank() || app.label.contains(state.query, true) || app.packageName.contains(state.query, true))
        }
    }
    val webApps = remember(state.apps, state.query) {
        state.apps.filter { it.isWebApp && (state.query.isBlank() || it.label.contains(state.query, true) || it.packageName.contains(state.query, true)) }
    }
    val shownShortcuts = remember(state.shortcuts, state.query) {
        if (state.query.isBlank()) state.shortcuts else state.shortcuts.filter { it.title.contains(state.query, true) || it.url.contains(state.query, true) }
    }
    val selectedApps = remember(state.apps, state.selected) { state.apps.filter { it.packageName in state.selected } }
    val selectedBytes = remember(selectedApps) { selectedApps.fold(0L) { sum, app -> safeAdd(sum, app.totalBytes) } }
    val selectedApkFiles = remember(selectedApps) { selectedApps.sumOf { it.expectedSplitCount + 1 } }
    val filters = MainViewModel.Filter.values().filterNot { it == MainViewModel.Filter.WEB_SHORTCUTS }
    val layoutDirection = if (LocaleManager.isArabic()) LayoutDirection.Rtl else LayoutDirection.Ltr
    LaunchedEffect(state.filter) {
        if (state.filter == MainViewModel.Filter.WEB_SHORTCUTS) activeTab = AppTab.WEB
    }

    val baseDensity = LocalDensity.current
    CompositionLocalProvider(
        LocalDensity provides Density(baseDensity.density, baseDensity.fontScale * if (state.largeTextMode) 1.15f else 1f),
        LocalLayoutDirection provides layoutDirection
    ) {
        MaterialTheme(colorScheme = darkColorScheme(primary = Emerald, secondary = Cyan, background = Background, surface = SurfaceCard, error = ErrorRed)) {
            Scaffold(
                containerColor = Background,
                bottomBar = {
                    Column {
                        if (activeTab == AppTab.BACKUP) {
                            Surface(color = SurfaceCard, shadowElevation = 14.dp) {
                                Row(
                                    Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 14.dp, vertical = 9.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(Modifier.weight(1f)) {
                                        Text(stringResource(R.string.selected_apps_summary, state.selected.size, selectedApkFiles, formatBytes(selectedBytes)), color = Emerald, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                                        Text(if (state.storageUri == null) stringResource(R.string.storage_not_selected) else state.storageName, color = Color.LightGray, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelSmall)
                                    }
                                    Button(onClick = startExport, enabled = !state.exporting, colors = ButtonDefaults.buttonColors(containerColor = Emerald, contentColor = Background), shape = RoundedCornerShape(12.dp)) {
                                        Text(stringResource(R.string.copy_to_usb), fontWeight = FontWeight.Black, style = MaterialTheme.typography.labelMedium)
                                    }
                                }
                            }
                        }
                        NavigationBar(containerColor = SurfaceCard, contentColor = Emerald) {
                            NavigationBarItem(selected = activeTab == AppTab.BACKUP, onClick = { activeTab = AppTab.BACKUP; model.setQuery(""); if (state.filter == MainViewModel.Filter.WEB_SHORTCUTS) model.setFilter(MainViewModel.Filter.ALL) }, icon = { Text("01", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold) }, label = { Text(stringResource(R.string.tab_backup)) }, alwaysShowLabel = true)
                            NavigationBarItem(selected = activeTab == AppTab.WEB, onClick = { activeTab = AppTab.WEB; model.setQuery("") }, icon = { Icon(Icons.Default.Link, null) }, label = { Text(stringResource(R.string.tab_web)) }, alwaysShowLabel = true)
                            NavigationBarItem(selected = activeTab == AppTab.TOOLS, onClick = { activeTab = AppTab.TOOLS }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text(stringResource(R.string.tab_tools)) }, alwaysShowLabel = true)
                        }
                    }
                }
            ) { scaffoldPadding ->
                Column(Modifier.fillMaxSize().padding(scaffoldPadding).padding(horizontal = 14.dp)) {
                    Header(model)
                    if (activeTab != AppTab.TOOLS) StorageCard(state, onChoose = { picker.launch(null) })
                    state.error?.let { Text(it, color = ErrorRed, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 4.dp)) }
                    when (activeTab) {
                        AppTab.BACKUP -> {
                            Text(stringResource(R.string.backup_overview), color = Color.LightGray, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 7.dp, bottom = 6.dp))
                            OutlinedTextField(
                                value = state.query, onValueChange = model::setQuery, modifier = Modifier.fillMaxWidth(), singleLine = true,
                                placeholder = { Text(stringResource(R.string.search_hint)) }, leadingIcon = { Icon(Icons.Default.Search, null, tint = Cyan) },
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Emerald, unfocusedBorderColor = Color(0xFF34434A))
                            )
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
                                items(filters) { filter -> FilterChip(selected = state.filter == filter, onClick = { model.setFilter(filter) }, label = { Text(filterLabel(filter)) }) }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp)) {
                                Text(stringResource(R.string.item_count, shown.size), color = Cyan, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.labelSmall)
                                Spacer(Modifier.weight(1f))
                                TextButton(onClick = { model.selectAllVisible(shown.map { it.packageName }) }) { Text(stringResource(R.string.select_all), color = Emerald) }
                            }
                            if (state.loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Emerald)
                            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                items(shown, key = { it.packageName }) { app -> AppRow(app, app.packageName in state.selected) { model.toggle(app.packageName) } }
                                if (shown.isEmpty() && !state.loading) item { EmptyCard(stringResource(R.string.error_no_apps)) }
                            }
                        }
                        AppTab.WEB -> {
                            OutlinedTextField(
                                value = state.query, onValueChange = model::setQuery, modifier = Modifier.fillMaxWidth().padding(top = 8.dp), singleLine = true,
                                placeholder = { Text(stringResource(R.string.search_hint)) }, leadingIcon = { Icon(Icons.Default.Search, null, tint = Cyan) },
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Emerald, unfocusedBorderColor = Color(0xFF34434A))
                            )
                            Card(colors = CardDefaults.cardColors(containerColor = SurfaceCard), modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 7.dp)) {
                                Column(Modifier.padding(10.dp)) {
                                    Text(stringResource(R.string.shortcuts_section_hint), color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                        OutlinedButton(onClick = { shortcutTitle = ""; shortcutUrl = ""; model.showShortcutDialog(true) }) { Text(stringResource(R.string.shortcut_add)) }
                                        TextButton(onClick = model::selectAllShortcuts, enabled = state.shortcuts.isNotEmpty()) { Text(stringResource(R.string.select_all_links), color = Emerald) }
                                        TextButton(onClick = model::clearShortcutSelection, enabled = state.selectedShortcuts.isNotEmpty()) { Text(stringResource(R.string.shortcut_clear_selection), color = Color.LightGray) }
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Button(onClick = model::exportSelectedShortcuts, enabled = state.selectedShortcuts.isNotEmpty(), colors = ButtonDefaults.buttonColors(containerColor = Emerald, contentColor = Background)) { Text(stringResource(R.string.export_to_storage)) }
                                        TextButton(onClick = { confirmDeleteShortcuts = true }, enabled = state.selectedShortcuts.isNotEmpty()) { Text(stringResource(R.string.shortcut_delete_selected, state.selectedShortcuts.size), color = ErrorRed) }
                                    }
                                    state.shortcutMessage?.let { Text(it, color = Cyan, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 4.dp)) }
                                }
                            }
                            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                item(key = "web-apps-heading") { SectionHeader(stringResource(R.string.web_apps_header), webApps.size) }
                                items(webApps, key = { "webapp:${it.packageName}" }) { app -> AppRow(app, app.packageName in state.selected) { model.toggle(app.packageName) } }
                                item(key = "saved-links-heading") { SectionHeader(stringResource(R.string.web_links_header), shownShortcuts.size) }
                                items(shownShortcuts, key = { "link:${it.url}" }) { shortcut -> ShortcutRow(shortcut.title, shortcut.url, shortcut.url in state.selectedShortcuts, { model.toggleShortcut(shortcut.url) }) {
                                    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(shortcut.url))) }
                                } }
                                if (webApps.isEmpty() && shownShortcuts.isEmpty()) item { EmptyCard(stringResource(R.string.shortcuts_empty)) }
                            }
                        }
                        AppTab.TOOLS -> {
                            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                item {
                                    Card(colors = CardDefaults.cardColors(containerColor = SurfaceCard), modifier = Modifier.fillMaxWidth()) {
                                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Text(stringResource(R.string.tools_privacy_title), color = Emerald, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                            Text(stringResource(R.string.tools_privacy_text), color = Color.White, style = MaterialTheme.typography.bodyMedium)
                                            Text(stringResource(R.string.about_owner), color = Cyan, style = MaterialTheme.typography.labelSmall)
                                            Text(stringResource(R.string.about_privacy), color = Color.LightGray, style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                }
                                item {
                                    Card(colors = CardDefaults.cardColors(containerColor = SurfaceCard), modifier = Modifier.fillMaxWidth()) {
                                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Text(stringResource(R.string.tab_tools), color = Emerald, fontWeight = FontWeight.Bold)
                                            PreferenceSwitch(stringResource(R.string.pref_single_worker_title), stringResource(R.string.pref_single_worker_hint), state.singleWorkerMode, model::setSingleWorkerMode)
                                            PreferenceSwitch(stringResource(R.string.pref_hide_notification_names_title), stringResource(R.string.pref_hide_notification_names_hint), state.hideNotificationNames, model::setHideNotificationNames)
                                            PreferenceSwitch(stringResource(R.string.pref_large_text_title), stringResource(R.string.pref_large_text_hint), state.largeTextMode, model::setLargeTextMode)
                                        }
                                    }
                                }
                                item {
                                    Card(colors = CardDefaults.cardColors(containerColor = SurfaceCard), modifier = Modifier.fillMaxWidth()) {
                                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Text(stringResource(R.string.tools_apk_inspector), color = Emerald, fontWeight = FontWeight.Bold)
                                            Text(stringResource(R.string.apk_inspector_scope), color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                                            OutlinedButton(onClick = { apkPicker.launch(arrayOf("application/vnd.android.package-archive")) }, enabled = !state.inspectingApk) { Text(stringResource(R.string.tools_apk_inspector)) }
                                            if (state.inspectingApk) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Cyan)
                                            state.apkInspectionError?.let { Text(it, color = ErrorRed, style = MaterialTheme.typography.bodySmall) }
                                        }
                                    }
                                }
                                item {
                                    Card(colors = CardDefaults.cardColors(containerColor = SurfaceCard), modifier = Modifier.fillMaxWidth()) {
                                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Text(stringResource(R.string.tools_storage_browser), color = Emerald, fontWeight = FontWeight.Bold)
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                TextButton(onClick = model::refreshBackupFiles, enabled = state.storageUri != null) { Text(stringResource(R.string.storage_browser_refresh), color = Cyan) }
                                                Text(stringResource(R.string.package_count, state.backupFiles.size), color = Color.LightGray, style = MaterialTheme.typography.labelSmall)
                                            }
                                            if (state.backupFiles.isEmpty()) Text(stringResource(R.string.storage_browser_empty), color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                                            state.backupFiles.take(30).forEach { file ->
                                                val isReport = file.name.endsWith(".html", true) || file.name.endsWith(".txt", true) || file.name.endsWith(".json", true)
                                                if (isReport) TextButton(onClick = { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(file.uri, file.mimeType ?: "text/plain").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) } }) {
                                                    Text(stringResource(R.string.open_report, file.name, formatBytes(file.size)), maxLines = 1, overflow = TextOverflow.Ellipsis, color = Cyan)
                                                } else Text(stringResource(R.string.storage_file_item, file.name, formatBytes(file.size)), color = Color.White, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 12.dp, top = 4.dp))
                                            }
                                        }
                                    }
                                }
                                item {
                                    Card(colors = CardDefaults.cardColors(containerColor = SurfaceCard), modifier = Modifier.fillMaxWidth()) {
                                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Text(stringResource(R.string.diagnostics_title), color = Emerald, fontWeight = FontWeight.Bold)
                                            Text(stringResource(R.string.diagnostics_hint), color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                                            val status = when {
                                                state.exporting -> stringResource(R.string.exporting)
                                                state.batchFinished -> stringResource(R.string.export_finished_summary, state.done, state.total, state.failedPackages.size)
                                                else -> stringResource(R.string.diagnostics_no_result)
                                            }
                                            val safeDiagnostic = stringResource(R.string.diagnostics_summary, com.f6lab.coreextractor.BuildConfig.VERSION_NAME, Build.VERSION.SDK_INT, "${Build.MANUFACTURER} ${Build.MODEL}", status)
                                            OutlinedButton(onClick = { diagnosticPreview = safeDiagnostic }) { Text(stringResource(R.string.diagnostics_share)) }
                                        }
                                    }
                                }
                                item {
                                    Card(colors = CardDefaults.cardColors(containerColor = SurfaceCard), modifier = Modifier.fillMaxWidth()) {
                                        Column(Modifier.padding(12.dp)) {
                                            Text(stringResource(R.string.tools_rescan), color = Emerald, fontWeight = FontWeight.Bold)
                                            Text(stringResource(R.string.package_count, state.apps.size), color = Color.LightGray, style = MaterialTheme.typography.labelSmall)
                                            Button(onClick = model::reload, enabled = !state.loading, modifier = Modifier.padding(top = 6.dp)) { Text(stringResource(R.string.tools_rescan)) }
                                        }
                                    }
                                }
                                item {
                                    Card(onClick = { showConsole = !showConsole }, colors = CardDefaults.cardColors(containerColor = SurfaceCard), modifier = Modifier.fillMaxWidth()) {
                                        Column(Modifier.padding(12.dp)) {
                                            Text(stringResource(R.string.tools_console), color = Emerald, fontWeight = FontWeight.Bold)
                                            if (showConsole) state.console.takeLast(20).forEach { line -> Text(line, color = if (line.contains("failed", true) || line.contains("فشل")) ErrorRed else Cyan, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.labelSmall, maxLines = 2, overflow = TextOverflow.Ellipsis) }
                                        }
                                    }
                                }
                                item {
                                    OutlinedButton(onClick = { model.showAbout(true) }, modifier = Modifier.fillMaxWidth()) {
                                        Icon(Icons.Default.Info, null); Spacer(Modifier.width(8.dp)); Text(stringResource(R.string.tools_about))
                                    }
                                }
                            }
                        }
                    }
                    if (state.uiHidden) {
                        Card(onClick = model::showExportInterface, colors = CardDefaults.cardColors(containerColor = SurfaceRaised), modifier = Modifier.fillMaxWidth().padding(bottom = 5.dp)) {
                            Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(stringResource(if (state.exporting) R.string.export_running_background else R.string.export_background_finished), color = Cyan, modifier = Modifier.weight(1f))
                                TextButton(onClick = model::showExportInterface) { Text(stringResource(R.string.show_export_ui), color = Emerald) }
                            }
                        }
                    }
                }
            }
            if (state.showAbout) AboutDialog { model.showAbout(false) }
            if (state.shortcutDialogVisible) AlertDialog(
                onDismissRequest = { model.showShortcutDialog(false) },
                title = { Text(stringResource(R.string.shortcut_add_title), color = Emerald) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(stringResource(R.string.shortcut_add_hint), color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                        OutlinedTextField(value = shortcutTitle, onValueChange = { shortcutTitle = it }, label = { Text(stringResource(R.string.shortcut_name)) }, singleLine = true)
                        OutlinedTextField(value = shortcutUrl, onValueChange = { shortcutUrl = it }, label = { Text(stringResource(R.string.shortcut_url)) }, singleLine = true)
                    }
                },
                confirmButton = { TextButton(onClick = { model.addShortcut(shortcutTitle, shortcutUrl) }) { Text(stringResource(R.string.shortcut_save), color = Emerald) } },
                dismissButton = { TextButton(onClick = { model.showShortcutDialog(false) }) { Text(stringResource(R.string.close), color = Color.LightGray) } },
                containerColor = SurfaceRaised
            )
            if (confirmDeleteShortcuts) AlertDialog(
                onDismissRequest = { confirmDeleteShortcuts = false },
                title = { Text(stringResource(R.string.shortcuts_delete_confirm_title), color = ErrorRed) },
                text = { Text(stringResource(R.string.shortcuts_delete_confirm_message, state.selectedShortcuts.size), color = Color.White) },
                confirmButton = { TextButton(onClick = { model.deleteSelectedShortcuts(); confirmDeleteShortcuts = false }) { Text(stringResource(R.string.shortcut_delete_selected, state.selectedShortcuts.size), color = ErrorRed) } },
                dismissButton = { TextButton(onClick = { confirmDeleteShortcuts = false }) { Text(stringResource(R.string.close), color = Color.LightGray) } },
                containerColor = SurfaceRaised
            )
            if (state.progressVisible) ExportProgressDialog(state, model) { model.selectFailedPackages(); model.closeProgress(); showBatchPreview = true }
            if (showBatchPreview) {
                val previewFiles = selectedApps.take(5).map { app -> previewOutputName(app, batchLabel) }
                AlertDialog(
                    onDismissRequest = { showBatchPreview = false },
                    title = { Text(stringResource(R.string.batch_preview_title), color = Emerald) },
                    text = {
                        Column(Modifier.heightIn(max = 440.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(stringResource(R.string.batch_preview_counts, selectedApps.size, selectedApkFiles, formatBytes(selectedBytes)), color = Cyan)
                            OutlinedTextField(value = batchLabel, onValueChange = { batchLabel = it.take(40) }, label = { Text(stringResource(R.string.batch_label)) }, supportingText = { Text(stringResource(R.string.batch_label_hint)) }, singleLine = true)
                            Text(stringResource(R.string.batch_collision_hint), color = Amber, style = MaterialTheme.typography.bodySmall)
                            previewFiles.forEach { Text(stringResource(R.string.batch_preview_file, it), color = Color.White, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis) }
                            if (selectedApps.size > previewFiles.size) Text("+${selectedApps.size - previewFiles.size}", color = Color.LightGray)
                        }
                    },
                    confirmButton = { TextButton(onClick = confirmExport) { Text(stringResource(R.string.batch_start), color = Emerald) } },
                    dismissButton = { TextButton(onClick = { showBatchPreview = false }) { Text(stringResource(R.string.close), color = Color.LightGray) } },
                    containerColor = SurfaceRaised
                )
            }
            if (state.apkInspection != null) {
                val result = state.apkInspection!!
                AlertDialog(onDismissRequest = { model.clearApkInspection() }, title = { Text(stringResource(R.string.apk_inspect_title), color = Emerald) }, text = { Text(stringResource(R.string.apk_inspect_result, result.label, result.packageName, result.version, result.versionCode, result.targetSdk, formatBytes(result.fileSize), result.certificateSha256), color = Color.White) }, confirmButton = { TextButton(onClick = { model.clearApkInspection() }) { Text(stringResource(R.string.close)) } }, containerColor = SurfaceRaised)
            }
            diagnosticPreview?.let { report ->
                AlertDialog(onDismissRequest = { diagnosticPreview = null }, title = { Text(stringResource(R.string.diagnostics_title), color = Emerald) }, text = { Text(report, color = Color.White) }, confirmButton = { TextButton(onClick = {
                    val share = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, report)
                    runCatching { context.startActivity(Intent.createChooser(share, context.getString(R.string.diagnostics_chooser))) }
                    diagnosticPreview = null
                }) { Text(stringResource(R.string.diagnostics_share), color = Emerald) } }, dismissButton = { TextButton(onClick = { diagnosticPreview = null }) { Text(stringResource(R.string.close)) } }, containerColor = SurfaceRaised)
            }
        }
    }
}

@Composable
private fun PreferenceSwitch(title: String, hint: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
            Text(hint, color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

private fun previewOutputName(app: AppRepository.AppItem, label: String): String {
    val safeLabel = app.label.replace(Regex("[^\\p{L}\\p{N}._ -]"), "_").trim().ifBlank { "App" }
    val prefix = label.trim().replace(Regex("[^\\p{L}\\p{N}._ -]"), "_").take(40).trim().let { if (it.isBlank()) "" else "${it}_" }
    val version = app.versionName.replace(Regex("[^\\p{L}\\p{N}._-]"), "_").ifBlank { "unknown" }
    val pkg = app.packageName.replace(Regex("[^\\p{L}\\p{N}._-]"), "_")
    val ext = if (app.expectedSplitCount > 0) "apks" else "apk"
    return "${prefix}${safeLabel}_v${version}_${pkg}.$ext"
}

@Composable
private fun Header(model: MainViewModel) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(stringResource(R.string.app_name), color = Emerald, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black, style = MaterialTheme.typography.headlineSmall)
            Text(stringResource(R.string.home_local_badge), color = Cyan, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.labelSmall)
        }
        TextButton(onClick = { LocaleManager.setLanguage("ar") }) { Text("ع", color = if (LocaleManager.isArabic()) Emerald else Color.LightGray, fontWeight = FontWeight.Bold) }
        Text("/", color = Color.LightGray)
        TextButton(onClick = { LocaleManager.setLanguage("en") }) { Text("EN", color = if (!LocaleManager.isArabic()) Emerald else Color.LightGray, fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun StorageCard(state: MainViewModel.UiState, onChoose: () -> Unit) {
    Card(onClick = onChoose, colors = CardDefaults.cardColors(containerColor = SurfaceCard), shape = RoundedCornerShape(15.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.FolderOpen, null, tint = Cyan, modifier = Modifier.size(26.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.storage_picker), color = Emerald, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.labelSmall)
                Text(if (state.storageUri == null) stringResource(R.string.storage_not_selected) else state.storageName, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                val stats = state.storageStats
                Text(if (stats != null) stringResource(R.string.storage_stats, formatBytes(stats.first), formatBytes(stats.second)) else stringResource(R.string.package_count, state.apps.size), color = Color.LightGray, style = MaterialTheme.typography.labelSmall)
            }
            Text("●", color = if (state.storageUri != null) Emerald else Amber, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun ExportProgressDialog(state: MainViewModel.UiState, model: MainViewModel, onRetryFailed: () -> Unit) {
    val bytesRemaining = (state.bytesTotal - state.bytes).coerceAtLeast(0L)
    val etaSeconds = if (state.speedBytesPerSecond > 0L && bytesRemaining > 0L) ceil(bytesRemaining.toDouble() / state.speedBytesPerSecond).toLong() else null
    val eta = etaSeconds?.let(::formatDuration)
    val finishAt = etaSeconds?.let { SimpleDateFormat(if (it >= 24 * 3600) "EEE HH:mm dd/MM" else "HH:mm", Locale.getDefault()).format(Date(System.currentTimeMillis() + it * 1000L)) }
    val appRemaining = (state.total - state.done).coerceAtLeast(0)
    val fileRemaining = (state.totalFiles - state.copiedFiles).coerceAtLeast(0)
    AlertDialog(
        onDismissRequest = { if (state.exporting) model.hideExportInterface() else model.closeProgress() },
        title = { Text(stringResource(R.string.export_title), color = Emerald, fontFamily = FontFamily.Monospace) },
        text = {
            Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (state.exporting) Text("${stringResource(R.string.exporting)} · ${state.current.ifBlank { stringResource(R.string.preparing) }}", color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (state.thermalPaused) Text(stringResource(R.string.thermal_pause_message), color = Amber, fontWeight = FontWeight.Bold)
                val fraction = if (state.bytesTotal > 0L) state.bytes.toFloat() / state.bytesTotal else 0f
                LinearProgressIndicator(progress = { fraction.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth(), color = Emerald)
                Text(stringResource(R.string.bytes_progress, formatBytes(state.bytes), formatBytes(state.bytesTotal)), color = Cyan, fontFamily = FontFamily.Monospace)
                Text(stringResource(R.string.export_apps_progress, state.done, state.total, appRemaining), color = Color.White, style = MaterialTheme.typography.bodySmall)
                Text(stringResource(R.string.export_files_progress, state.copiedFiles, state.totalFiles), color = Color.White, style = MaterialTheme.typography.bodySmall)
                Text(stringResource(R.string.export_files_remaining, fileRemaining), color = Cyan, style = MaterialTheme.typography.bodySmall)
                Text(stringResource(R.string.transfer_speed, formatBytes(state.speedBytesPerSecond)), color = Emerald, fontFamily = FontFamily.Monospace)
                Text(stringResource(R.string.export_eta_remaining, eta ?: stringResource(R.string.export_eta_calculating)), color = Amber, fontWeight = FontWeight.Bold)
                finishAt?.let { Text(stringResource(R.string.export_eta_finish, it), color = Color.LightGray, style = MaterialTheme.typography.bodySmall) }
                if (state.batchFinished) Text(stringResource(R.string.safe_eject_hint), color = Amber, style = MaterialTheme.typography.bodySmall)
                state.results.takeLast(5).forEach { Text(it, color = if (it.contains("SUCCESS") || it.startsWith("نجح")) Emerald else if (it.contains("FAILED") || it.startsWith("فشل")) ErrorRed else Color.White, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis) }
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                if (state.exporting) TextButton(onClick = model::stopExport) { Text(stringResource(R.string.stop), color = ErrorRed) }
                else {
                    if (state.failedPackages.isNotEmpty()) TextButton(onClick = onRetryFailed) { Text(stringResource(R.string.retry_failed, state.failedPackages.size), color = Amber) }
                    TextButton(onClick = model::closeProgress) { Text(stringResource(R.string.close), color = Emerald) }
                }
            }
        },
        dismissButton = { if (state.exporting) TextButton(onClick = model::hideExportInterface) { Text(stringResource(R.string.hide_export_ui), color = Cyan) } },
        containerColor = SurfaceRaised
    )
}

@Composable
private fun AppRow(app: AppRepository.AppItem, selected: Boolean, onClick: () -> Unit) {
    var bitmap by remember(app.packageName) { mutableStateOf(iconCache.get(app.packageName)) }
    var detailsExpanded by remember(app.packageName) { mutableStateOf(false) }
    LaunchedEffect(app.packageName) {
        val loaded = withContext(Dispatchers.IO) { iconCache.get(app.packageName) ?: runCatching { app.icon.toBitmap(80, 80) }.getOrNull() }
        if (loaded != null) iconCache.put(app.packageName, loaded)
        bitmap = loaded
    }
    Card(onClick = onClick, colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFF12291F) else SurfaceCard), shape = RoundedCornerShape(13.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(horizontal = 9.dp, vertical = 7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(selected, { onClick() }, colors = CheckboxDefaults.colors(checkedColor = Emerald))
                if (bitmap != null) Image(bitmap!!.asImageBitmap(), null, modifier = Modifier.size(38.dp))
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(app.label, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                    Text(app.packageName, color = Color.LightGray, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelSmall)
                    Text("${formatBytes(app.totalBytes)} · ${if (app.expectedSplitCount > 0) stringResource(R.string.format_auto_apks, app.expectedSplitCount) else stringResource(R.string.format_auto_apk)}", color = Cyan, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelSmall)
                }
                TextButton(onClick = { detailsExpanded = !detailsExpanded }) { Text(stringResource(if (detailsExpanded) R.string.less_details else R.string.more_details), color = Emerald, style = MaterialTheme.typography.labelSmall) }
            }
            if (detailsExpanded) {
                HorizontalDivider(color = Color(0xFF2D4147), modifier = Modifier.padding(vertical = 5.dp))
                Text(stringResource(R.string.app_details), color = Emerald, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                Text(stringResource(R.string.app_version_metadata, app.versionName, app.versionCode), color = Color.White, style = MaterialTheme.typography.labelSmall)
                Text("API ${app.targetSdk} · ${app.architectures.joinToString().ifBlank { stringResource(R.string.no_native_abi) }}", color = Cyan, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.labelSmall)
                Text(stringResource(R.string.app_certificate_metadata, app.certificateSha256), color = Color.LightGray, maxLines = 2, overflow = TextOverflow.Ellipsis, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.labelSmall)
                val riskTags = app.riskTags.map { localizedRisk(it) }
                val tags = buildList {
                    if (app.isSystem) add(stringResource(R.string.tag_system))
                    if (riskTags.isNotEmpty()) add(stringResource(R.string.tag_sensitive, riskTags.joinToString()))
                    add(stringResource(if (app.source == ForensicInspector.Source.GOOGLE_PLAY) R.string.tag_play else R.string.tag_unknown_source))
                    if (app.oldTargetSdk) add(stringResource(R.string.tag_old_sdk))
                }
                Text(tags.joinToString(" · "), color = if (app.riskTags.isNotEmpty()) Amber else Emerald, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun localizedRisk(tag: String): String = stringResource(when (tag) {
    "Camera" -> R.string.risk_camera
    "Location" -> R.string.risk_location
    "Contacts" -> R.string.risk_contacts
    "Microphone" -> R.string.risk_microphone
    "Call log" -> R.string.risk_call_log
    "SMS" -> R.string.risk_sms
    "Display over other apps" -> R.string.risk_overlay
    "Modify system settings" -> R.string.risk_system_settings
    else -> R.string.unavailable
})

@Composable
private fun ShortcutRow(title: String, url: String, selected: Boolean, onToggle: () -> Unit, onOpen: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = SurfaceCard), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(horizontal = 7.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(selected, { onToggle() }, colors = CheckboxDefaults.colors(checkedColor = Emerald))
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(url, color = Cyan, style = MaterialTheme.typography.labelSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            TextButton(onClick = onOpen) { Text(stringResource(R.string.shortcut_open), color = Emerald) }
        }
    }
}

@Composable
private fun SectionHeader(title: String, count: Int) {
    Row(Modifier.fillMaxWidth().padding(top = 5.dp, bottom = 1.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Emerald, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(7.dp))
        Text(count.toString(), color = Cyan, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun EmptyCard(message: String) {
    Card(colors = CardDefaults.cardColors(containerColor = SurfaceCard), modifier = Modifier.fillMaxWidth()) {
        Text(message, color = Color.LightGray, modifier = Modifier.padding(14.dp), style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun filterLabel(filter: MainViewModel.Filter): String = stringResource(when (filter) {
    MainViewModel.Filter.ALL -> R.string.filter_all
    MainViewModel.Filter.USER -> R.string.filter_user
    MainViewModel.Filter.SYSTEM -> R.string.filter_system
    MainViewModel.Filter.HIGH_RISK -> R.string.filter_risk
    MainViewModel.Filter.SIDELOADED -> R.string.filter_sideloaded
    MainViewModel.Filter.OLD_TARGET -> R.string.filter_old_sdk
    MainViewModel.Filter.WEB_SHORTCUTS -> R.string.filter_web_shortcuts
})

private fun safeAdd(a: Long, b: Long): Long = if (Long.MAX_VALUE - a < b) Long.MAX_VALUE else a + b

private fun formatBytes(bytes: Long): String = when {
    bytes < 1024L -> "$bytes B"
    bytes < 1024L * 1024 -> String.format(Locale.US, "%.1f KB", bytes / 1024.0)
    bytes < 1024L * 1024 * 1024 -> String.format(Locale.US, "%.1f MB", bytes / 1024.0 / 1024.0)
    bytes < 1024L * 1024 * 1024 * 1024 -> String.format(Locale.US, "%.2f GB", bytes / 1024.0 / 1024.0 / 1024.0)
    else -> String.format(Locale.US, "%.2f TB", bytes / 1024.0 / 1024.0 / 1024.0 / 1024.0)
}

private fun formatDuration(totalSeconds: Long): String {
    val seconds = totalSeconds.coerceAtLeast(0L)
    val hours = seconds / 3600
    val minutes = (seconds % 3600) / 60
    val remainingSeconds = seconds % 60
    return if (hours > 0) String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, remainingSeconds)
    else String.format(Locale.US, "%02d:%02d", minutes, remainingSeconds)
}
