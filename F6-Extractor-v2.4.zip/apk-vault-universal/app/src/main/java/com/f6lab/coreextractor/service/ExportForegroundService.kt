package com.f6lab.coreextractor.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.IBinder
import java.util.concurrent.TimeUnit
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.f6lab.coreextractor.ExportRuntime
import com.f6lab.coreextractor.LocaleManager
import com.f6lab.coreextractor.MainActivity
import com.f6lab.coreextractor.R
import com.f6lab.coreextractor.data.AppRepository
import com.f6lab.coreextractor.data.ReportGenerator
import com.f6lab.coreextractor.data.SAFStorageManager
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch

/** User-initiated SAF export isolated from the UI by an Android foreground service. */
class ExportForegroundService : Service() {
    companion object {
        const val ACTION_START = "com.f6lab.coreextractor.action.START_EXPORT"
        const val ACTION_CANCEL = "com.f6lab.coreextractor.action.CANCEL_EXPORT"
        const val ACTION_HIDE_UI = "com.f6lab.coreextractor.action.HIDE_EXPORT_UI"
        const val ACTION_SHOW_UI = "com.f6lab.coreextractor.action.SHOW_EXPORT_UI"
        const val EXTRA_PACKAGES = "packages"
        const val EXTRA_TOTAL_BYTES = "total_bytes"
        const val EXTRA_TOTAL_FILES = "total_files"
        const val EXTRA_BATCH_LABEL = "batch_label"
        const val EXTRA_SINGLE_WORKER = "single_worker"
        const val EXTRA_HIDE_APP_NAMES = "hide_app_names"
        private const val CHANNEL_ID = "f6_export"
        private const val NOTIFICATION_ID = 2101
        private const val COMPLETE_NOTIFICATION_ID = 2102
        private const val MAX_PARALLEL_APPS = 2
        private const val UI_INTERVAL_MS = 900L
        private const val NOTIFICATION_INTERVAL_MS = 1800L
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler by lazy { android.os.Handler(mainLooper) }
    private var exportJob: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null
    @Volatile private var latest = ExportRuntime.Snapshot()
    private val lastNotificationAt = AtomicLong(0L)

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CANCEL -> exportJob?.cancel(CancellationException(localized(R.string.export_cancelled)))
            ACTION_HIDE_UI -> ExportRuntime.hide()
            ACTION_SHOW_UI -> {
                ExportRuntime.show()
                ExportRuntime.publish(latest, force = true)
            }
            ACTION_START -> startExport(intent, startId)
            else -> stopSelfResult(startId)
        }
        return START_NOT_STICKY
    }

    private fun startExport(intent: Intent, startId: Int) {
        if (exportJob?.isActive == true) return
        val treeUri = intent.data ?: run { stopSelfResult(startId); return }
        val packageNames = intent.getStringArrayListExtra(EXTRA_PACKAGES).orEmpty().distinct()
        if (packageNames.isEmpty()) { stopSelfResult(startId); return }
        val totalBytes = intent.getLongExtra(EXTRA_TOTAL_BYTES, 0L).coerceAtLeast(0L)
        val totalFiles = intent.getIntExtra(EXTRA_TOTAL_FILES, packageNames.size).coerceAtLeast(packageNames.size)
        val batchLabel = intent.getStringExtra(EXTRA_BATCH_LABEL).orEmpty().take(40)
        val maxWorkers = if (intent.getBooleanExtra(EXTRA_SINGLE_WORKER, false)) 1 else MAX_PARALLEL_APPS
        val hideAppNames = intent.getBooleanExtra(EXTRA_HIDE_APP_NAMES, true)

        latest = ExportRuntime.Snapshot(running = true, totalApps = packageNames.size, totalBytes = totalBytes, totalFiles = totalFiles, hideAppNames = hideAppNames)
        ExportRuntime.begin(packageNames.size, totalBytes, totalFiles, hideAppNames)
        startAsForeground(buildProgressNotification(latest))
        acquireWakeLock()

        exportJob = serviceScope.launch {
            try {
                runBatch(treeUri, packageNames, totalBytes, totalFiles, batchLabel, maxWorkers)
            } catch (cancelled: CancellationException) {
                latest = latest.copy(running = false, current = "", summary = localized(R.string.export_cancelled))
                ExportRuntime.publish(latest, force = true)
                notifyCompletion(latest.summary)
            } catch (error: Exception) {
                latest = latest.copy(running = false, current = "", summary = localized(R.string.export_failed_summary, error.message ?: ""))
                ExportRuntime.publish(latest, force = true)
                notifyCompletion(latest.summary)
            } finally {
                releaseWakeLock()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelfResult(startId)
            }
        }
    }

    private suspend fun runBatch(treeUri: Uri, packageNames: List<String>, knownTotalBytes: Long, totalFiles: Int, batchLabel: String, maxWorkers: Int) {
        val repo = AppRepository(applicationContext)
        val saf = SAFStorageManager(applicationContext)
        val resultLock = Any()
        val exported = ArrayList<SAFStorageManager.Exported>(packageNames.size)
        val failures = ArrayList<String>(10)
        val failedPackages = linkedSetOf<String>()
        val thermalPauseCount = AtomicInteger(0)
        val successCount = AtomicInteger(0)
        val failureCount = AtomicInteger(0)
        val completedApps = AtomicInteger(0)
        val copiedFiles = AtomicInteger(0)
        val copiedBytes = AtomicLong(0L)
        val bytesByPackage = ConcurrentHashMap<String, Long>()
        val activeApps = ConcurrentHashMap.newKeySet<String>()
        val bytesTotal = AtomicLong(knownTotalBytes)
        val lastSampleBytes = AtomicLong(0L)
        val lastSampleTime = AtomicLong(SystemClock.elapsedRealtime())
        val transferSpeed = AtomicLong(0L)
        val lastUiUpdate = AtomicLong(0L)
        latest = latest.copy(running = true, totalApps = packageNames.size, totalBytes = bytesTotal.get(), totalFiles = totalFiles)
        ExportRuntime.publish(latest)

        val queue = Channel<Pair<Int, String>>(Channel.UNLIMITED)
        packageNames.forEachIndexed { index, name -> queue.trySend(index to name) }
        queue.close()

        try {
            kotlinx.coroutines.coroutineScope {
                val workers = List(minOf(maxWorkers, packageNames.size)) {
                    launch(Dispatchers.IO) {
                        val workerJob = currentCoroutineContext()[Job]
                        for ((_, packageName) in queue) {
                            if (!isActive) break
                            activeApps.add(packageName)
                            try {
                                val source = repo.getExportSource(packageName)
                                    ?: error(localized(R.string.export_package_unavailable, packageName))
                                if (knownTotalBytes == 0L) bytesTotal.updateAndGet { saturatingAdd(it, source.totalBytes) }

                                val result = saf.export(
                                    uri = treeUri,
                                    app = source,
                                    onBytes = { copiedForApp, _ ->
                                        val previous = bytesByPackage.put(packageName, copiedForApp) ?: 0L
                                        val copied = copiedBytes.addAndGet((copiedForApp - previous).coerceAtLeast(0L))
                                        val now = SystemClock.elapsedRealtime()
                                        val sampleTime = lastSampleTime.get()
                                        if (now - sampleTime >= 1000L && lastSampleTime.compareAndSet(sampleTime, now)) {
                                            val elapsed = (now - sampleTime).coerceAtLeast(1L)
                                            val oldBytes = lastSampleBytes.getAndSet(copied)
                                            transferSpeed.set((copied - oldBytes).coerceAtLeast(0L) * 1000L / elapsed)
                                        }
                                        val previousUi = lastUiUpdate.get()
                                        if (now - previousUi >= UI_INTERVAL_MS && lastUiUpdate.compareAndSet(previousUi, now)) {
                                            publishProgress(
                                                completedApps.get(), packageNames.size, copied, bytesTotal.get(), activeApps.toList(),
                                                transferSpeed.get(), successCount.get(), failureCount.get(), failureSnapshot(resultLock, failures), copiedFiles.get(), totalFiles
                                            )
                                            updateProgressNotification(latest)
                                        }
                                    },
                                    isCancelled = { workerJob?.isActive != true },
                                    batchLabel = batchLabel,
                                    shouldPause = { isThermalSevere() },
                                    onThermalPause = { paused ->
                                        val count = if (paused) thermalPauseCount.incrementAndGet() else thermalPauseCount.updateAndGet { (it - 1).coerceAtLeast(0) }
                                        latest = latest.copy(thermalPaused = count > 0)
                                        ExportRuntime.publish(latest)
                                        updateProgressNotification(latest, force = true)
                                    }
                                )
                                synchronized(resultLock) { exported.add(result) }
                                copiedFiles.addAndGet(result.hashes.size)
                                successCount.incrementAndGet()
                            } catch (cancelled: CancellationException) {
                                throw cancelled
                            } catch (error: Exception) {
                                failureCount.incrementAndGet()
                                synchronized(resultLock) {
                                    failedPackages.add(packageName)
                                    if (failures.size < 10) failures.add("$packageName: ${error.message.orEmpty()}")
                                }
                            } finally {
                                activeApps.remove(packageName)
                                val completedNow = completedApps.incrementAndGet()
                                val now = SystemClock.elapsedRealtime()
                                val previousUi = lastUiUpdate.get()
                                if ((now - previousUi >= UI_INTERVAL_MS || completedNow == packageNames.size) &&
                                    lastUiUpdate.compareAndSet(previousUi, now)) {
                                    publishProgress(
                                        completedNow, packageNames.size, copiedBytes.get(), bytesTotal.get(), activeApps.toList(),
                                        transferSpeed.get(), successCount.get(), failureCount.get(), failureSnapshot(resultLock, failures), copiedFiles.get(), totalFiles
                                    )
                                }
                                updateProgressNotification(latest)
                            }
                        }
                    }
                }
                workers.joinAll()
            }
        } finally {
            queue.cancel()
        }

        val reports = try {
            withContextIo { ReportGenerator.write(applicationContext, saf, treeUri, synchronized(resultLock) { exported.toList() }) }
            true
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: Exception) {
            failureCount.incrementAndGet()
            synchronized(resultLock) { if (failures.size < 10) failures.add("Report: ${error.message.orEmpty()}") }
            false
        }
        val summary = localized(R.string.export_finished_summary, successCount.get(), packageNames.size, failureCount.get())
        latest = latest.copy(
            running = false,
            current = "",
            completedApps = completedApps.get(),
            totalApps = packageNames.size,
            copiedFiles = copiedFiles.get(),
            totalFiles = totalFiles,
            copiedBytes = copiedBytes.get(),
            totalBytes = bytesTotal.get(),
            bytesPerSecond = 0L,
            successCount = successCount.get(),
            failureCount = failureCount.get(),
            summary = if (reports) summary else "$summary · ${localized(R.string.log_report_failed)}",
            failureSamples = failureSnapshot(resultLock, failures),
            failedPackages = synchronized(resultLock) { failedPackages.toList() },
            thermalPaused = false
        )
        ExportRuntime.publish(latest, force = true)
        updateProgressNotification(latest, force = true)
        notifyCompletion(latest.summary)
    }

    /** Kept separate for clarity: caller is already running on the service's IO scope. */
    private suspend fun <T> withContextIo(block: suspend () -> T): T = kotlinx.coroutines.withContext(Dispatchers.IO) { block() }

    private fun failureSnapshot(lock: Any, failures: List<String>): List<String> = synchronized(lock) { failures.toList() }

    private fun publishProgress(
        completed: Int, total: Int, bytes: Long, totalBytes: Long, activeNames: List<String>, speed: Long,
        successes: Int, failuresCount: Int, failures: List<String>, copiedFiles: Int, totalFiles: Int
    ) {
        latest = latest.copy(
            running = true,
            current = activeNames.take(MAX_PARALLEL_APPS).joinToString(" · "),
            completedApps = completed,
            totalApps = total,
            copiedFiles = copiedFiles,
            totalFiles = totalFiles,
            copiedBytes = bytes,
            totalBytes = totalBytes,
            bytesPerSecond = speed,
            successCount = successes,
            failureCount = failuresCount,
            failureSamples = failures
        )
        ExportRuntime.publish(latest)
    }

    private fun isThermalSevere(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && runCatching {
        val power = getSystemService(POWER_SERVICE) as PowerManager
        power.currentThermalStatus >= PowerManager.THERMAL_STATUS_SEVERE
    }.getOrDefault(false)

    private fun startAsForeground(notification: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else startForeground(NOTIFICATION_ID, notification)
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val power = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "F6Extractor:Export").apply {
            setReferenceCounted(false)
            acquire(TimeUnit.HOURS.toMillis(24))
        }
    }

    private fun releaseWakeLock() {
        runCatching { if (wakeLock?.isHeld == true) wakeLock?.release() }
        wakeLock = null
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(CHANNEL_ID, localized(R.string.export_notification_channel), NotificationManager.IMPORTANCE_LOW).apply {
            description = localized(R.string.export_notification_description)
            setShowBadge(false)
        }
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
    }

    private fun buildProgressNotification(snapshot: ExportRuntime.Snapshot): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val cancel = PendingIntent.getService(
            this, 1, Intent(this, ExportForegroundService::class.java).setAction(ACTION_CANCEL),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val percent = if (snapshot.totalBytes > 0L) ((snapshot.copiedBytes * 100L) / snapshot.totalBytes).toInt().coerceIn(0, 100) else 0
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(if (snapshot.thermalPaused) localized(R.string.thermal_pause_message) else localized(R.string.export_notification_progress, snapshot.completedApps, snapshot.totalApps, snapshot.copiedFiles, snapshot.totalFiles))
            .setSubText(if (snapshot.hideAppNames) localized(R.string.notification_names_hidden) else snapshot.current.takeIf { it.isNotBlank() })
            .setContentIntent(openApp)
            .setOngoing(snapshot.running)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setProgress(100, percent, snapshot.totalBytes <= 0L)
            .addAction(0, localized(R.string.stop), cancel)
            .build()
    }

    private fun updateProgressNotification(snapshot: ExportRuntime.Snapshot, force: Boolean = false) {
        val now = SystemClock.elapsedRealtime()
        val last = lastNotificationAt.get()
        if (!force && now - last < NOTIFICATION_INTERVAL_MS) return
        if (!lastNotificationAt.compareAndSet(last, now) && !force) return
        mainHandler.post {
            runCatching { (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFICATION_ID, buildProgressNotification(snapshot)) }
        }
    }

    private fun notifyCompletion(summary: String) {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_upload_done)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(summary)
            .setAutoCancel(true)
            .setOnlyAlertOnce(true)
            .build()
        runCatching { (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(COMPLETE_NOTIFICATION_ID, notification) }
    }

    private fun localized(resource: Int, vararg args: Any): String =
        LocaleManager.localizedContext(applicationContext).getString(resource, *args)

    private fun saturatingAdd(left: Long, right: Long): Long =
        if (right > 0L && Long.MAX_VALUE - left < right) Long.MAX_VALUE else left + right

    override fun onDestroy() {
        exportJob?.cancel()
        releaseWakeLock()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
