package com.f6lab.coreextractor.data

import android.content.Context
import android.content.res.Configuration
import android.os.LocaleList
import com.f6lab.coreextractor.LocaleManager
import com.f6lab.coreextractor.R
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ReportGenerator {
    fun write(context: Context, storage: SAFStorageManager, treeUri: android.net.Uri, exported: List<SAFStorageManager.Exported>, operator: String = "Academy F6-Team | Zaher Abbas Muhammad") {
        val locale = Locale.forLanguageTag(LocaleManager.currentLanguage())
        val config = Configuration(context.resources.configuration).apply { setLocales(LocaleList(locale)) }
        val localized = context.createConfigurationContext(config)
        fun text(id: Int, vararg args: Any): String = localized.getString(id, *args)
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", locale).format(Date())
        val checksum = buildString {
            appendLine("${localized.getString(R.string.app_name)} · SHA-256")
            appendLine("${text(R.string.report_time)}: $stamp")
            exported.forEach { app -> app.hashes.forEach { (file, hash) -> appendLine("$hash  $file  [${app.packageName}]") } }
        }
        val rows = exported.joinToString("\n") { item ->
            val risk = item.riskTags.map { label ->
                val resource = when (label) {
                    "Camera" -> R.string.risk_camera
                    "Location" -> R.string.risk_location
                    "Contacts" -> R.string.risk_contacts
                    "Microphone" -> R.string.risk_microphone
                    "Call log" -> R.string.risk_call_log
                    "SMS" -> R.string.risk_sms
                    "Display over other apps" -> R.string.risk_overlay
                    "Modify system settings" -> R.string.risk_system_settings
                    else -> 0
                }
                if (resource == 0) label else text(resource)
            }.joinToString().ifBlank { text(R.string.report_no_risk) }
            val type = text(if (item.isSplit) R.string.report_split else R.string.report_base_apk)
            val architectures = item.architectures.map { if (it == "none") text(R.string.no_native_abi) else it }.joinToString()
            val certificate = if (item.certificateSha256 == "Unavailable") text(R.string.unavailable) else item.certificateSha256
            "<tr><td>${esc(item.displayName)}</td><td>${esc(item.packageName)}</td><td>${esc(item.version)}</td><td>${item.versionCode}</td><td>${item.size}</td><td>${item.targetSdk}</td><td>${esc(architectures)}</td><td>${esc(risk)}</td><td>${esc(certificate)}</td><td>${esc(type)}</td></tr>"
        }
        val html = """<!doctype html><html lang="${locale.language}" dir="${if (LocaleManager.isArabic()) "rtl" else "ltr"}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>${text(R.string.report_title)}</title><style>body{background:#050505;color:#d8ffe6;font:15px monospace;padding:24px}h1{color:#00ff66}table{border-collapse:collapse;width:100%}td,th{border:1px solid #087f43;padding:8px;text-align:start}small{color:#00d4ff}</style></head><body><h1>${text(R.string.report_title)}</h1><p>${text(R.string.report_time)}: $stamp<br>${text(R.string.report_operator)}: ${esc(operator)}<br>${text(R.string.report_offline)}</p><table><thead><tr><th>${text(R.string.report_file)}</th><th>${text(R.string.report_package)}</th><th>${text(R.string.report_version)}</th><th>${text(R.string.report_version_code)}</th><th>${text(R.string.report_size)}</th><th>${text(R.string.report_sdk)}</th><th>${text(R.string.report_arch)}</th><th>${text(R.string.report_risk)}</th><th>${text(R.string.report_cert)}</th><th>${text(R.string.report_type)}</th></tr></thead><tbody>$rows</tbody></table><p><small>${text(R.string.report_footer)}</small></p></body></html>"""
        val sh = buildString {
            appendLine("#!/system/bin/sh")
            appendLine("# F6 Extractor ADB restore helper; run from a computer with adb and unzip installed.")
            appendLine("set -eu")
            exported.forEach { item ->
                if (item.isSplit) {
                    val archive = shellQuote(item.displayName)
                    val directory = shellQuote(item.packageName + "_apks")
                    appendLine("mkdir -p $directory")
                    appendLine("unzip -o $archive -d $directory >/dev/null")
                    appendLine("adb install-multiple -r $directory/*.apk")
                } else appendLine("adb install -r ${shellQuote(item.displayName)}")
            }
        }
        val bat = buildString {
            appendLine("@echo off")
            appendLine("REM Run in the backup folder on a computer with adb and PowerShell installed.")
            exported.forEach { item ->
                if (item.isSplit) {
                    val directory = item.packageName + "_apks"
                    appendLine("powershell -NoProfile -Command \"Expand-Archive -Force '${item.displayName.replace("'", "''")}' '$directory'\"")
                    appendLine("adb install-multiple -r $directory\\*.apk")
                } else appendLine("adb install -r \"${item.displayName.replace("\"", "\"\"")}\"")
            }
            appendLine("pause")
        }
        storage.createText(treeUri, "checksum.txt", "text/plain", checksum)
        storage.createText(treeUri, "permissions_audit.html", "text/html", html)
        storage.createText(treeUri, "install_all.sh", "text/x-shellscript", sh)
        storage.createText(treeUri, "install_all.bat", "application/octet-stream", bat)
    }

    private fun esc(value: String) = value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&#39;")
    private fun shellQuote(value: String) = "'" + value.replace("'", "'\\''") + "'"
}
