package com.f6lab.coreextractor.data

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import java.io.File
import java.util.zip.ZipFile

object ForensicInspector {
    data class Inspection(val architectures: List<String>, val riskTags: List<String>, val source: Source, val certificateSha256: String)
    enum class Source { GOOGLE_PLAY, OTHER, UNKNOWN }
    private val riskPermissionLabels = linkedMapOf(
        "android.permission.CAMERA" to "Camera", "android.permission.ACCESS_FINE_LOCATION" to "Location",
        "android.permission.ACCESS_COARSE_LOCATION" to "Location", "android.permission.READ_CONTACTS" to "Contacts",
        "android.permission.WRITE_CONTACTS" to "Contacts", "android.permission.RECORD_AUDIO" to "Microphone",
        "android.permission.READ_CALL_LOG" to "Call log", "android.permission.READ_SMS" to "SMS",
        "android.permission.SYSTEM_ALERT_WINDOW" to "Display over other apps", "android.permission.WRITE_SETTINGS" to "Modify system settings"
    )

    fun inspect(context: Context, info: PackageInfo, apkFiles: List<File>): Inspection {
        val abis = linkedSetOf<String>()
        apkFiles.forEach { apk -> runCatching {
            ZipFile(apk).use { zip ->
                val entries = zip.entries()
                while (entries.hasMoreElements()) {
                    val path = entries.nextElement().name
                    if (path.startsWith("lib/")) path.split('/').getOrNull(1)?.let(abis::add)
                }
            }
        } }
        val architectureNames = abis.map { when (it) {
            "arm64-v8a" -> "arm64-v8a"; "armeabi-v7a", "armeabi" -> "v7a"; "x86", "x86_64" -> it; else -> it
        } }.distinct().ifEmpty { listOf("none") }
        @Suppress("DEPRECATION")
        val permissions = info.requestedPermissions?.toSet().orEmpty()
        val risks = riskPermissionLabels.filterKeys { it in permissions }.values.distinct()
        val source = if (Build.VERSION.SDK_INT >= 30) {
            runCatching {
                val installer = context.packageManager.getInstallSourceInfo(info.packageName).installingPackageName
                when (installer) { "com.android.vending" -> Source.GOOGLE_PLAY; null -> Source.UNKNOWN; else -> Source.OTHER }
            }.getOrDefault(Source.UNKNOWN)
        } else Source.UNKNOWN
        val certHash = runCatching {
            if (Build.VERSION.SDK_INT >= 28) {
                info.signingInfo?.apkContentsSigners?.firstOrNull()?.toByteArray()
            } else {
                @Suppress("DEPRECATION")
                info.signatures?.firstOrNull()?.toByteArray()
            }
        }.getOrNull()?.let { bytes -> java.security.MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { b -> "%02x".format(b) } } ?: "Unavailable"
        return Inspection(architectureNames, risks, source, certHash)
    }

    fun requestedSensitivePermissions(info: PackageInfo): List<String> =
        info.requestedPermissions.orEmpty().filter { it in riskPermissionLabels.keys }.mapNotNull(riskPermissionLabels::get).distinct()
}
