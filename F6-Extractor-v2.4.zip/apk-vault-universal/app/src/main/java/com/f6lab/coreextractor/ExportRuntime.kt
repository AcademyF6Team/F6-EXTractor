package com.f6lab.coreextractor

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/** Process-local, low-frequency status shared by the foreground service and UI. */
object ExportRuntime {
    data class Snapshot(
        val running: Boolean = false,
        val hidden: Boolean = false,
        val thermalPaused: Boolean = false,
        val hideAppNames: Boolean = true,
        val current: String = "",
        val completedApps: Int = 0,
        val totalApps: Int = 0,
        val copiedFiles: Int = 0,
        val totalFiles: Int = 0,
        val copiedBytes: Long = 0L,
        val totalBytes: Long = 0L,
        val bytesPerSecond: Long = 0L,
        val successCount: Int = 0,
        val failureCount: Int = 0,
        val summary: String = "",
        val failureSamples: List<String> = emptyList(),
        val failedPackages: List<String> = emptyList()
    )

    private val mutable = MutableStateFlow(Snapshot())
    val state = mutable.asStateFlow()

    fun begin(totalApps: Int, totalBytes: Long, totalFiles: Int, hideAppNames: Boolean = true) {
        mutable.value = Snapshot(running = true, totalApps = totalApps, totalBytes = totalBytes, totalFiles = totalFiles, hideAppNames = hideAppNames)
    }

    /** Suppresses all routine state emissions while hidden; completion/failure is still delivered. */
    fun publish(snapshot: Snapshot, force: Boolean = false) {
        if (force || !mutable.value.hidden) mutable.value = snapshot.copy(hidden = mutable.value.hidden)
    }

    fun hide() { mutable.update { it.copy(hidden = true) } }
    fun show() { mutable.update { it.copy(hidden = false) } }
    fun reset() { mutable.value = Snapshot() }
}
