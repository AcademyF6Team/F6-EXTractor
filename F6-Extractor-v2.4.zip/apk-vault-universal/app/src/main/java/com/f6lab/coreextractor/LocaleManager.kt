package com.f6lab.coreextractor

import android.content.Context
import android.content.res.Configuration
import android.os.LocaleList
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import java.util.Locale

/** Uses AppCompat's per-app locale API; switching recreates the Activity, not the app process. */
object LocaleManager {
    fun currentLanguage(): String {
        val selected = AppCompatDelegate.getApplicationLocales().toLanguageTags().substringBefore('-')
        return selected.ifBlank { Locale.getDefault().language.substringBefore('-') }.let { if (it == "ar") "ar" else "en" }
    }
    fun isArabic(): Boolean = currentLanguage() == "ar"
    fun localizedContext(base: Context): Context {
        val locale = Locale.forLanguageTag(currentLanguage())
        val configuration = Configuration(base.resources.configuration).apply { setLocales(LocaleList(locale)) }
        return base.createConfigurationContext(configuration)
    }
    fun setLanguage(language: String) {
        val tag = if (language == "ar") "ar" else "en"
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag))
    }
    fun toggleLanguage() = setLanguage(if (isArabic()) "en" else "ar")
}
